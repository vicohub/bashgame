WIP game in bash 
Please launch TheGame.sh to launch the game